const basePage = {

  goto(relativeUrl = '') {
    cy.visit('')
  }
}
export default basePage
