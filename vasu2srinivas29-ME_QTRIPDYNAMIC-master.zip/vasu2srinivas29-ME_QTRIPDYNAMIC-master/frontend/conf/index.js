
const config = { backendEndpoint: "https://vasu-qtrip-dynamic.herokuapp.com/" };
//const config = { backendEndpoint: "http://3.109.248.161:8082" };

export default config;
